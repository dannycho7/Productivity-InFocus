var current = new URI(window.location.href);
console.log(current.domain());